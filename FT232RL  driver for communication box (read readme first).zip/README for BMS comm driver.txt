YOU PROBABLY DO NOT NEED THE DRIVER

Read before installing the communication box driver

Try using the USB communication box BEFORE installing the driver. 


The box is a generic USB to TTL UART serial port adapter, \
most computers should be able to recognise it with standard usb drivers.


If successful, a new COM port will become available.

