These are the saved parameter files for each version of the Overkill Solar BMSs as of 6-8-2021.
Use the JBD desktop app to load the files, then write to the BMS.